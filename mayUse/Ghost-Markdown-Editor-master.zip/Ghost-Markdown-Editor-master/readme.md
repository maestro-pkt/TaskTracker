# Ghost Markdown Editor

Pulled this from Ghost ( http://ghost.org/features ). Its a responsive jquery markdown editor with instant preview.

## Screenshot

![Screenshot](https://raw.github.com/timsayshey/Ghost-Markdown-Editor/master/screenshot.png)

## Future

I would love to see someone release a full featured standalone version with the file/image upload placeholders, etc.

## Contribute

Feel free to make changes and issue a pull request.
