Please refer to [jQuery Mambo Plugin](http://valeriobarrila.com/mambo.html "jQuery Mambo Plugin") page because at the moment I didn't made a good README on GitHub (as you can see)

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/NinjaTux/mambo-jquery-plugin/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

