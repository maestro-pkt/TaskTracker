floatlabels.js
==============

Follows the famous Float Label Pattern. Built on jQuery.

Demo / Documentation:  
http://clubdesign.github.io/floatlabels.js/
