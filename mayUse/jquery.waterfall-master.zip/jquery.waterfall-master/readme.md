# jQuery.waterfall: [demo & docs](http://dfcreative.github.io/projects/waterfall/)

<a href="http://pinterest.com">Pinterest</a>-like layout with fluid width of columns. Fast, tiny, reliable and free alternative to <a href="http://isotope.metafizzy.co/custom-layout-modes/masonry-column-shift.html">isotope masonry column shift</a> layout.