jsPlumbTestSupport = {
    getAttribute:function(el, att) {
        return el.attr(att);
    },
    droppableClass:"ui-droppable"
};