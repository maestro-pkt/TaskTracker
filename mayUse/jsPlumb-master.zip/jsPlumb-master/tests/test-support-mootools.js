jsPlumbTestSupport = {
    getAttribute:function(el, att) {
        return el.getAttribute(att);
    },
    droppableClass:"jsplumb-mootools-droppable"
};