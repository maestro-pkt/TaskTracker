jsPlumbTestSupport = {
    getAttribute:function(el, att) {
        return el.getAttribute(att);
    },
    droppableClass:"yui3-dd-drop"
};