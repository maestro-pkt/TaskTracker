fancy-timeline
==============

Html + Javascript general porpouse timeline

## How to
Light documentation:[wiki](https://github.com/juanma-aguero/fancy-timeline/wiki/How-to).

## Examples
Here is a small live example:[example](http://flowcode.com.ar/fancy-timeline/examples/default/index.html).

## Upcoming features
* native video support
* customization examples
* more themes!

## Author
Juan Manuel Aguero: [web](http://juanmaaguero.com.ar/).
